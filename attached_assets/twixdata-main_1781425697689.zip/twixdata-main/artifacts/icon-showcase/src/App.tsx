import Lottie from "lottie-react";
import { useState } from "react";

import successAnim from "@assets/lottieflow-success-08-000000-easey_1781367391892.json";
import pinterestAnim from "@assets/lottieflow-social-networks-16-8-000000-easey_1781367392005.json";
import instagramAnim from "@assets/lottieflow-social-networks-16-5-000000-easey_1781367392047.json";
import facebookAnim from "@assets/lottieflow-social-networks-16-3-000000-easey_1781367392097.json";
import whatsappAnim from "@assets/lottieflow-social-networks-16-11-000000-easey_1781367392143.json";
import twitterAnim from "@assets/lottieflow-social-networks-16-10-000000-easey_1781367392193.json";
import searchAnim from "@assets/lottieflow-search-02-000000-easey_1781367392237.json";
import scrollDownAnim from "@assets/lottieflow-scroll-down-01-000000-easey_1781367392411.json";
import scrollingAnim from "@assets/lottieflow-scrolling-05-2-000000-easey_1781367392501.json";
import musicAnim from "@assets/lottieflow-multimedia-8-8-000000-easey_1781367392571.json";
import muteAnim from "@assets/lottieflow-multimedia-8-9-000000-easey_1781367392639.json";
import prevAnim from "@assets/lottieflow-multimedia-8-12-000000-easey_1781367392709.json";
import volAnim from "@assets/lottieflow-multimedia-8-14-000000-easey_1781367392781.json";
import menuAnim from "@assets/lottieflow-menu-nav-11-2-000000-easey_1781367392833.json";
import playStopAnim from "@assets/lottieflow-multimedia-8-11-000000-easey_1781367392876.json";
import likeAnim from "@assets/lottieflow-ecommerce-14-14-000000-easey_1781367392935.json";
import pinAnim from "@assets/lottieflow-ecommerce-14-15-000000-easey_1781367393012.json";
import countdownAnim from "@assets/lottieflow-countdown-13-10-000000-easey_1781367393074.json";
import dislikeAnim from "@assets/lottieflow-ecommerce-14-10-000000-easey_1781367393161.json";

const icons = [
  { name: "Success", category: "UI", anim: successAnim },
  { name: "Menu", category: "Navigation", anim: menuAnim },
  { name: "Search", category: "UI", anim: searchAnim },
  { name: "Scroll Down", category: "Navigation", anim: scrollDownAnim },
  { name: "Page Scroll", category: "Navigation", anim: scrollingAnim },
  { name: "Play / Stop", category: "Multimedia", anim: playStopAnim },
  { name: "Music", category: "Multimedia", anim: musicAnim },
  { name: "Mute", category: "Multimedia", anim: muteAnim },
  { name: "Previous", category: "Multimedia", anim: prevAnim },
  { name: "Volume", category: "Multimedia", anim: volAnim },
  { name: "Like", category: "Ecommerce", anim: likeAnim },
  { name: "Dislike", category: "Ecommerce", anim: dislikeAnim },
  { name: "Pin", category: "Ecommerce", anim: pinAnim },
  { name: "Countdown", category: "UI", anim: countdownAnim },
  { name: "Facebook", category: "Social", anim: facebookAnim },
  { name: "Instagram", category: "Social", anim: instagramAnim },
  { name: "Twitter / X", category: "Social", anim: twitterAnim },
  { name: "Pinterest", category: "Social", anim: pinterestAnim },
  { name: "WhatsApp", category: "Social", anim: whatsappAnim },
];

const categories = ["All", ...Array.from(new Set(icons.map((i) => i.category)))];

const categoryColors: Record<string, string> = {
  All: "#6366f1",
  UI: "#8b5cf6",
  Navigation: "#3b82f6",
  Multimedia: "#ec4899",
  Ecommerce: "#f59e0b",
  Social: "#10b981",
};

function IconCard({ name, anim, category }: { name: string; anim: object; category: string }) {
  const [hovered, setHovered] = useState(false);

  return (
    <div
      className="icon-card"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div className="icon-anim">
        <Lottie
          animationData={anim}
          loop={hovered}
          autoplay={hovered}
          style={{ width: 80, height: 80 }}
        />
      </div>
      <p className="icon-name">{name}</p>
      <span className="icon-badge" style={{ background: categoryColors[category] + "22", color: categoryColors[category] }}>
        {category}
      </span>
    </div>
  );
}

export default function App() {
  const [active, setActive] = useState("All");

  const filtered = active === "All" ? icons : icons.filter((i) => i.category === active);

  return (
    <div className="page">
      <header className="header">
        <h1 className="title">Lottie Icons</h1>
        <p className="subtitle">Hover over an icon to play the animation</p>
      </header>

      <div className="filter-bar">
        {categories.map((cat) => (
          <button
            key={cat}
            className={`filter-btn ${active === cat ? "active" : ""}`}
            style={active === cat ? { background: categoryColors[cat], color: "#fff", borderColor: categoryColors[cat] } : {}}
            onClick={() => setActive(cat)}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="grid">
        {filtered.map((icon) => (
          <IconCard key={icon.name} name={icon.name} anim={icon.anim} category={icon.category} />
        ))}
      </div>

      <footer className="footer">
        <span>{icons.length} icons · LottieFlow</span>
      </footer>
    </div>
  );
}
