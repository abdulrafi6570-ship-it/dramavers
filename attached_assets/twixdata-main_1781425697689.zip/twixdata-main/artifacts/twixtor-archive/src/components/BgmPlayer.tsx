import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import Lottie, { type LottieRefCurrentProps } from "lottie-react";
import musicAnim from "@assets/lottieflow-multimedia-8-8-000000-easey_1781367392571.json";
import muteAnim from "@assets/lottieflow-multimedia-8-9-000000-easey_1781367392639.json";
import volAnim from "@assets/lottieflow-multimedia-8-14-000000-easey_1781367392781.json";
import playStopAnim from "@assets/lottieflow-multimedia-8-11-000000-easey_1781367392876.json";

interface BgmPlayerProps {
  src: string;
}

function LottieIcon({
  anim,
  size = 16,
  playing = true,
}: {
  anim: object;
  size?: number;
  playing?: boolean;
}) {
  const ref = useRef<LottieRefCurrentProps>(null);
  useEffect(() => {
    if (playing) ref.current?.play();
    else ref.current?.pause();
  }, [playing]);
  return (
    <Lottie
      lottieRef={ref}
      animationData={anim}
      loop
      autoplay={playing}
      style={{ width: size, height: size, filter: "invert(1)", opacity: 0.5 }}
    />
  );
}

export function BgmPlayer({ src }: BgmPlayerProps) {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(false);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setTimeout(() => setVisible(true), 3000);
  }, []);

  useEffect(() => {
    if (!audioRef.current || !src) return;
    const audio = audioRef.current;
    audio.volume = 0.3;
    audio.loop = true;

    if ("mediaSession" in navigator) {
      navigator.mediaSession.metadata = null;
      navigator.mediaSession.setActionHandler("play", null);
      navigator.mediaSession.setActionHandler("pause", null);
      navigator.mediaSession.setActionHandler("previoustrack", null);
      navigator.mediaSession.setActionHandler("nexttrack", null);
    }

    const tryPlay = () => {
      audio.play()
        .then(() => {
          setPlaying(true);
          if ("mediaSession" in navigator) {
            navigator.mediaSession.metadata = null;
          }
        })
        .catch(() => {});
    };
    tryPlay();
    document.addEventListener("click", tryPlay, { once: true });
    return () => document.removeEventListener("click", tryPlay);
  }, [src]);

  const toggle = () => {
    if (!audioRef.current) return;
    if (playing) {
      audioRef.current.pause();
      setPlaying(false);
    } else {
      audioRef.current.play().then(() => setPlaying(true)).catch(() => {});
    }
  };

  const toggleMute = () => {
    if (!audioRef.current) return;
    audioRef.current.muted = !muted;
    setMuted(!muted);
  };

  if (!src) return null;

  return (
    <>
      <audio ref={audioRef} src={src} preload="none" />
      <motion.div
        drag
        dragMomentum={false}
        dragElastic={0}
        className="fixed bottom-6 right-6 z-[500] touch-none select-none transition-opacity duration-500"
        style={{ opacity: visible ? 1 : 0, y: visible ? 0 : 20, cursor: "grab" }}
        whileDrag={{ cursor: "grabbing", scale: 1.02 }}
      >
        <div className="glass-panel-strong rounded-full px-3 py-2 flex items-center gap-2 border border-white/10">
          <LottieIcon anim={musicAnim} size={14} playing={playing} />
          <button
            onClick={toggleMute}
            className="hover:opacity-100 transition-opacity flex items-center"
            title={muted ? "Unmute" : "Mute"}
          >
            <LottieIcon anim={muted ? muteAnim : volAnim} size={18} playing />
          </button>
          <button
            onClick={toggle}
            className={`w-6 h-6 rounded-full flex items-center justify-center transition-all ${
              playing ? "bg-white/20" : "bg-white/5"
            }`}
            title={playing ? "Pause" : "Play"}
          >
            <LottieIcon anim={playStopAnim} size={14} playing={playing} />
          </button>
        </div>
      </motion.div>
    </>
  );
}
