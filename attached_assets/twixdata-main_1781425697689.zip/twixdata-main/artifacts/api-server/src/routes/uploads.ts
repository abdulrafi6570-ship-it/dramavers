import { Router, type IRouter, type Request, type Response } from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import { randomUUID } from "crypto";
import { exec } from "child_process";
import { promisify } from "util";
import { requireAuth, requireAdmin } from "../middlewares/auth";

const execAsync = promisify(exec);
const router: IRouter = Router();

const UPLOADS_DIR = path.resolve(process.cwd(), "../../uploads");
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOADS_DIR),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${randomUUID()}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 2 * 1024 * 1024 * 1024 },
});

router.post("/uploads", requireAuth, requireAdmin, upload.single("file"), (req: Request, res: Response): void => {
  if (!req.file) {
    res.status(400).json({ error: "No file uploaded" });
    return;
  }
  const url = `/api/uploads/${req.file.filename}`;
  res.json({ url, filename: req.file.filename, size: req.file.size, mimetype: req.file.mimetype });
});

router.get("/uploads/:filename", (req: Request, res: Response): void => {
  const filename = String(req.params.filename);
  if (filename.includes("..") || filename.includes("/")) {
    res.status(400).json({ error: "Invalid filename" });
    return;
  }
  const filePath = path.join(UPLOADS_DIR, filename);
  if (!fs.existsSync(filePath)) {
    res.status(404).json({ error: "File not found" });
    return;
  }
  res.sendFile(filePath);
});

router.post("/uploads/mp3", requireAuth, requireAdmin, upload.single("file"), async (req: Request, res: Response): Promise<void> => {
  if (!req.file) {
    res.status(400).json({ error: "No file uploaded" });
    return;
  }
  const inputPath = req.file.path;
  const outputFilename = `${randomUUID()}.mp3`;
  const outputPath = path.join(UPLOADS_DIR, outputFilename);
  try {
    await execAsync(`ffmpeg -y -i "${inputPath}" -vn -acodec libmp3lame -q:a 2 "${outputPath}"`);
    const url = `/api/uploads/${outputFilename}`;
    res.json({ url, filename: outputFilename });
  } catch (err) {
    req.log.error({ err }, "ffmpeg conversion failed");
    res.status(500).json({ error: "Audio conversion failed" });
  } finally {
    fs.unlink(inputPath, () => {});
  }
});

export default router;
