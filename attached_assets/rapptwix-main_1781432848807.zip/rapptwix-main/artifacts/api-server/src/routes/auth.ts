import { Router, type IRouter } from "express";
import bcrypt from "bcryptjs";
import multer from "multer";
import path from "path";
import fs from "fs";
import { randomUUID } from "crypto";
import { db, usersTable, accessCodesTable, userFollowsTable } from "@workspace/db";
import { eq, and, or, gt, count } from "drizzle-orm";
import { requireAuth, generateToken } from "../middlewares/auth";
import { RegisterBody, LoginBody, VerifyAccessCodeBody } from "@workspace/api-zod";
import { z } from "zod";

const router: IRouter = Router();

const UPLOADS_DIR = path.resolve(process.cwd(), "../../uploads");
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });

const avatarStorage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOADS_DIR),
  filename: (_req, _file, cb) => cb(null, `avatar_${randomUUID()}.jpg`),
});
const avatarUpload = multer({
  storage: avatarStorage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (file.mimetype.startsWith("image/")) cb(null, true);
    else cb(new Error("Only image files allowed"));
  },
});

async function getUserWithCounts(userId: number) {
  const [dbUser] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!dbUser) return null;
  const [[{ followerCount }], [{ followingCount }]] = await Promise.all([
    db.select({ followerCount: count() }).from(userFollowsTable).where(eq(userFollowsTable.followingId, userId)),
    db.select({ followingCount: count() }).from(userFollowsTable).where(eq(userFollowsTable.followerId, userId)),
  ]);
  return {
    id: dbUser.id,
    username: dbUser.username,
    role: dbUser.role,
    verified: dbUser.verified,
    photoUrl: dbUser.photoUrl ?? null,
    bio: dbUser.bio ?? null,
    createdAt: dbUser.createdAt.toISOString(),
    followerCount: Number(followerCount),
    followingCount: Number(followingCount),
  };
}

router.post("/auth/register", async (req, res): Promise<void> => {
  const parsed = RegisterBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { username, password } = parsed.data;
  const [existing] = await db.select().from(usersTable).where(eq(usersTable.username, username));
  if (existing) { res.status(400).json({ error: "Username already taken" }); return; }
  const passwordHash = await bcrypt.hash(password, 12);
  const [user] = await db.insert(usersTable).values({ username, passwordHash, role: "user", verified: false }).returning();
  const token = generateToken({ id: user.id, username: user.username, role: user.role, verified: user.verified });
  res.status(201).json({
    user: { id: user.id, username: user.username, role: user.role, verified: user.verified, photoUrl: null, bio: null, createdAt: user.createdAt.toISOString(), followerCount: 0, followingCount: 0 },
    token,
  });
});

router.post("/auth/login", async (req, res): Promise<void> => {
  const parsed = LoginBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { username, password } = parsed.data;
  const [user] = await db.select().from(usersTable).where(eq(usersTable.username, username));
  if (!user) { res.status(401).json({ error: "Invalid credentials" }); return; }
  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) { res.status(401).json({ error: "Invalid credentials" }); return; }
  const token = generateToken({ id: user.id, username: user.username, role: user.role, verified: user.verified });
  const userWithCounts = await getUserWithCounts(user.id);
  res.json({ user: userWithCounts, token });
});

router.post("/auth/logout", async (_req, res): Promise<void> => {
  res.json({ success: true });
});

router.get("/auth/me", requireAuth, async (req, res): Promise<void> => {
  const userWithCounts = await getUserWithCounts(req.user!.id);
  if (!userWithCounts) { res.status(404).json({ error: "User not found" }); return; }
  res.json(userWithCounts);
});

router.patch("/auth/profile", requireAuth, async (req, res): Promise<void> => {
  const UpdateProfileBody = z.object({
    bio: z.string().max(300).optional(),
    photoUrl: z.string().optional(),
  });
  const parsed = UpdateProfileBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const updates: Record<string, string | null> = {};
  if (parsed.data.bio !== undefined) updates.bio = parsed.data.bio || null;
  if (parsed.data.photoUrl !== undefined) updates.photoUrl = parsed.data.photoUrl || null;
  await db.update(usersTable).set(updates as any).where(eq(usersTable.id, req.user!.id));
  const userWithCounts = await getUserWithCounts(req.user!.id);
  res.json(userWithCounts);
});

router.post("/auth/upload-photo", requireAuth, avatarUpload.single("photo"), async (req, res): Promise<void> => {
  if (!req.file) { res.status(400).json({ error: "No file uploaded" }); return; }
  const photoUrl = `/api/uploads/${req.file.filename}`;
  await db.update(usersTable).set({ photoUrl }).where(eq(usersTable.id, req.user!.id));
  const userWithCounts = await getUserWithCounts(req.user!.id);
  res.json({ photoUrl, user: userWithCounts });
});

router.post("/auth/verify-code", requireAuth, async (req, res): Promise<void> => {
  const parsed = VerifyAccessCodeBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }
  const { code } = parsed.data;
  const now = new Date();
  const [accessCode] = await db.select().from(accessCodesTable).where(
    and(
      eq(accessCodesTable.code, code),
      eq(accessCodesTable.active, true),
      or(eq(accessCodesTable.expiredAt, null as any), gt(accessCodesTable.expiredAt, now))
    )
  );
  if (!accessCode) { res.status(400).json({ error: "Invalid or expired code" }); return; }
  await db.update(usersTable).set({ verified: true }).where(eq(usersTable.id, req.user!.id));
  const userWithCounts = await getUserWithCounts(req.user!.id);
  res.json(userWithCounts);
});

export default router;
