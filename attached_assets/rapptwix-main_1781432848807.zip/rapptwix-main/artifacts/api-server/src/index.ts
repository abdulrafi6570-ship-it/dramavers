import app from "./app";
import { logger } from "./lib/logger";
import bcrypt from "bcryptjs";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

async function seedAdminUser() {
  try {
    const [existing] = await db.select().from(usersTable).where(eq(usersTable.role, "admin"));
    if (!existing) {
      const adminUsername = process.env.ADMIN_USERNAME || "owner";
      const adminPassword = process.env.ADMIN_PASSWORD || "twixtor2024";
      const passwordHash = await bcrypt.hash(adminPassword, 12);
      await db.insert(usersTable).values({
        username: adminUsername,
        passwordHash,
        role: "admin",
        verified: true,
      });
      logger.info({ username: adminUsername }, "Admin user seeded — login with the default credentials");
    }
  } catch (err) {
    logger.warn({ err }, "Could not seed admin user (DB may not be ready)");
  }
}

app.listen(port, async (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
  await seedAdminUser();
});
