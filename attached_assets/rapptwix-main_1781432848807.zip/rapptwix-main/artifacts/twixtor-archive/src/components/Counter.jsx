import { motion, useSpring, useTransform } from 'framer-motion';
import { useEffect } from 'react';
import './Counter.css';

function Number({ mv, number, height }) {
  let y = useTransform(mv, latest => {
    let placeValue = latest % 10;
    let offset = (10 + number - placeValue) % 10;
    let memo = offset * height;
    if (offset > 5) memo -= 10 * height;
    return memo;
  });
  return (
    <motion.span className="ctr-number" style={{ y }}>
      {number}
    </motion.span>
  );
}

function normalizeNearInteger(num) {
  const nearest = Math.round(num);
  const tolerance = 1e-9 * Math.max(1, Math.abs(num));
  return Math.abs(num - nearest) < tolerance ? nearest : num;
}

function getValueRoundedToPlace(value, place) {
  const scaled = value / place;
  return Math.floor(normalizeNearInteger(scaled));
}

function Digit({ place, value, height, digitStyle }) {
  const isDecimal = place === '.';
  const valueRoundedToPlace = isDecimal ? 0 : getValueRoundedToPlace(value, place);
  const animatedValue = useSpring(valueRoundedToPlace);

  useEffect(() => {
    if (!isDecimal) animatedValue.set(valueRoundedToPlace);
  }, [animatedValue, valueRoundedToPlace, isDecimal]);

  if (isDecimal) {
    return <span className="ctr-digit" style={{ height, ...digitStyle, width: 'fit-content' }}>.</span>;
  }

  return (
    <span className="ctr-digit" style={{ height, ...digitStyle }}>
      {Array.from({ length: 10 }, (_, i) => (
        <Number key={i} mv={animatedValue} number={i} height={height} />
      ))}
    </span>
  );
}

export default function Counter({
  value,
  fontSize = 100,
  padding = 0,
  places,
  gap = 8,
  borderRadius = 4,
  horizontalPadding = 8,
  textColor = 'inherit',
  fontWeight = 'inherit',
  containerStyle,
  counterStyle,
  digitStyle,
  gradientHeight = 16,
  gradientFrom = 'black',
  gradientTo = 'transparent',
  topGradientStyle,
  bottomGradientStyle
}) {
  const derivedPlaces = places ?? [...value.toString()].map((ch, i, a) => {
    if (ch === '.') return '.';
    const dotIdx = a.indexOf('.');
    return 10 ** (dotIdx === -1 ? a.length - i - 1 : i < dotIdx ? dotIdx - i - 1 : -(i - dotIdx));
  });

  const height = fontSize + padding;
  const defaultCounterStyle = {
    fontSize, gap, borderRadius, paddingLeft: horizontalPadding, paddingRight: horizontalPadding,
    color: textColor, fontWeight, direction: 'ltr'
  };
  const defaultTopGradientStyle = { height: gradientHeight, background: `linear-gradient(to bottom, ${gradientFrom}, ${gradientTo})` };
  const defaultBottomGradientStyle = { height: gradientHeight, background: `linear-gradient(to top, ${gradientFrom}, ${gradientTo})` };

  return (
    <span className="ctr-container" style={containerStyle}>
      <span className="ctr-counter" style={{ ...defaultCounterStyle, ...counterStyle }}>
        {derivedPlaces.map((place, i) => (
          <Digit key={i} place={place} value={value} height={height} digitStyle={digitStyle} />
        ))}
      </span>
      <span className="ctr-gradient-container">
        <span className="ctr-top-gradient" style={topGradientStyle ?? defaultTopGradientStyle} />
        <span className="ctr-bottom-gradient" style={bottomGradientStyle ?? defaultBottomGradientStyle} />
      </span>
    </span>
  );
}
