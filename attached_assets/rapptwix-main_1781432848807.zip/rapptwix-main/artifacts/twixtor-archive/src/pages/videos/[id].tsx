import { useGetVideo, getGetVideoQueryKey, useRecordView, useAddFavorite, useRemoveFavorite, useAddBookmark, useRemoveBookmark, useDownloadVideo, useListComments, getListCommentsQueryKey, useCreateComment, useDeleteComment } from "@workspace/api-client-react";
import { Navbar } from "@/components/layout/Navbar";
import { VideoCard } from "@/components/video/VideoCard";
import { useAuth } from "@/contexts/AuthContext";
import { Link, useParams, useLocation } from "wouter";
import { useState, useEffect, useRef } from "react";
import { ArrowLeft, Heart, Bookmark, Download, Copy, Play, MessageCircle, Trash2, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

const TIKTOK_USERNAME = "@rapzzelitcees1";
const TIKTOK_URL = "https://www.tiktok.com/@rapzzelitcees1";

export default function VideoDetail() {
  const params = useParams<{ id: string }>();
  const id = Number(params.id);
  const { user, verifyCode } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [, setLocation] = useLocation();
  const [showDownloadModal, setShowDownloadModal] = useState(false);
  const [downloadStep, setDownloadStep] = useState<"tiktok" | "code">("tiktok");
  const [codeInput, setCodeInput] = useState("");
  const [commentText, setCommentText] = useState("");
  const [videoAspect, setVideoAspect] = useState<number | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const { data: video, isLoading } = useGetVideo(id, { query: { enabled: !!id, queryKey: getGetVideoQueryKey(id) } });
  const { data: comments } = useListComments({ videoId: id }, { query: { enabled: !!id, queryKey: getListCommentsQueryKey({ videoId: id }) } });

  const recordView = useRecordView();
  const addFavorite = useAddFavorite();
  const removeFavorite = useRemoveFavorite();
  const addBookmark = useAddBookmark();
  const removeBookmark = useRemoveBookmark();
  const downloadVideo = useDownloadVideo();
  const createComment = useCreateComment();
  const deleteComment = useDeleteComment();

  useEffect(() => {
    if (id) recordView.mutate({ id });
  }, [id]);

  const invalidateVideo = () => qc.invalidateQueries({ queryKey: getGetVideoQueryKey(id) });
  const invalidateComments = () => qc.invalidateQueries({ queryKey: getListCommentsQueryKey({ videoId: id }) });

  async function handleDownloadClick() {
    if (!user) { setLocation("/login"); return; }
    if (!user.verified) {
      setDownloadStep("tiktok");
      setShowDownloadModal(true);
      return;
    }
    execDownload();
  }

  async function execDownload() {
    try {
      const res = await downloadVideo.mutateAsync({ id });
      const link = document.createElement("a");
      link.href = res.videoUrl;
      link.download = res.title;
      link.click();
      toast({ title: "Download dimulai!" });
    } catch {
      toast({ title: "Download gagal", variant: "destructive" });
    }
  }

  async function handleCopy() {
    await navigator.clipboard.writeText(window.location.href);
    toast({ title: "Link disalin!" });
  }

  async function handleVerify() {
    const ok = await verifyCode({ code: codeInput });
    if (ok) {
      setShowDownloadModal(false);
      setCodeInput("");
      execDownload();
    }
  }

  async function handleFavorite() {
    if (!user) { setLocation("/login"); return; }
    if (!video) return;
    if (video.isFavorited) await removeFavorite.mutateAsync({ videoId: id });
    else await addFavorite.mutateAsync({ videoId: id });
    invalidateVideo();
  }

  async function handleBookmark() {
    if (!user) { setLocation("/login"); return; }
    if (!video) return;
    if (video.isBookmarked) await removeBookmark.mutateAsync({ videoId: id });
    else await addBookmark.mutateAsync({ videoId: id });
    invalidateVideo();
  }

  async function handleComment() {
    if (!user) { setLocation("/login"); return; }
    if (!commentText.trim()) return;
    try {
      await createComment.mutateAsync({ data: { videoId: id, text: commentText } });
      setCommentText("");
      invalidateComments();
    } catch {
      toast({ title: "Gagal mengirim komentar", variant: "destructive" });
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <Navbar />
        <main className="container mx-auto px-4 md:px-6 py-8">
          <div className="aspect-video rounded-2xl bg-white/5 animate-pulse mb-8" />
        </main>
      </div>
    );
  }

  if (!video) return null;

  return (
    <div className="min-h-screen bg-background text-foreground pb-24 md:pb-0">
      <Navbar />
      <main className="container mx-auto px-4 md:px-6 py-8 max-w-7xl">
        <Link href="/videos" className="inline-flex items-center gap-2 text-white/40 hover:text-white mb-6 transition-colors text-sm">
          <ArrowLeft className="h-4 w-4" /> Back
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-5">
            {/* Player — adapts to actual video aspect ratio */}
            <div
              className="relative rounded-2xl overflow-hidden border border-white/10 bg-black flex items-center justify-center"
              style={
                videoAspect !== null
                  ? {
                      aspectRatio: String(videoAspect),
                      maxHeight: "85vh",
                      width: videoAspect < 1 ? "min(100%, calc(85vh * " + videoAspect + "))" : "100%",
                      margin: "0 auto",
                    }
                  : { aspectRatio: "9/16", maxHeight: "85vh", width: "min(100%, calc(85vh * 9 / 16))", margin: "0 auto" }
              }
            >
              {video.videoUrl ? (
                <video
                  ref={videoRef}
                  src={video.videoUrl}
                  controls
                  poster={video.thumbnailUrl ?? undefined}
                  className="w-full h-full object-contain"
                  onLoadedMetadata={(e) => {
                    const v = e.currentTarget;
                    if (v.videoWidth && v.videoHeight) {
                      setVideoAspect(v.videoWidth / v.videoHeight);
                    }
                  }}
                />
              ) : video.thumbnailUrl ? (
                <div className="relative w-full h-full">
                  <img src={video.thumbnailUrl} alt={video.title} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 flex items-center justify-center bg-black/40">
                    <div className="w-16 h-16 rounded-full bg-white/15 backdrop-blur flex items-center justify-center border border-white/20">
                      <Play className="h-7 w-7 text-white fill-white ml-1" />
                    </div>
                  </div>
                </div>
              ) : (
                <div className="w-full h-full bg-black/80 flex flex-col items-center justify-center gap-3">
                  <Play className="h-12 w-12 text-white/15" />
                  <p className="text-white/20 text-xs">Video belum diupload</p>
                </div>
              )}
            </div>

            {/* Action buttons */}
            <div className="space-y-3">
              <div className="flex flex-wrap gap-2">
                <Button
                  onClick={handleDownloadClick}
                  className="flex-1 sm:flex-none bg-white hover:bg-white/90 text-black font-semibold"
                  disabled={downloadVideo.isPending}
                >
                  <Download className="h-4 w-4 mr-2" />
                  Download
                </Button>
                <Button variant="outline" onClick={handleCopy} className="border-white/15 text-white hover:bg-white/8">
                  <Copy className="h-4 w-4 mr-2" />
                  Copy Link
                </Button>
                <Button
                  variant="outline"
                  onClick={handleFavorite}
                  className={`border-white/15 hover:bg-white/8 ${video.isFavorited ? "text-red-400 border-red-400/30" : "text-white"}`}
                >
                  <Heart className="h-4 w-4" fill={video.isFavorited ? "currentColor" : "none"} />
                </Button>
                <Button
                  variant="outline"
                  onClick={handleBookmark}
                  className={`border-white/15 hover:bg-white/8 ${video.isBookmarked ? "text-blue-400 border-blue-400/30" : "text-white"}`}
                >
                  <Bookmark className="h-4 w-4" fill={video.isBookmarked ? "currentColor" : "none"} />
                </Button>
              </div>

              {/* TikTok CTA below download */}
              <div className="glass-panel rounded-xl p-3 border border-white/8 flex items-center gap-3">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">
                  <svg viewBox="0 0 24 24" className="h-4 w-4 fill-white" xmlns="http://www.w3.org/2000/svg">
                    <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1V9.01a6.33 6.33 0 00-.79-.05 6.34 6.34 0 00-6.34 6.34 6.34 6.34 0 006.34 6.34 6.34 6.34 0 006.33-6.34V8.69a8.18 8.18 0 004.78 1.52V6.76a4.85 4.85 0 01-1.01-.07z"/>
                  </svg>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-white/50">Kode download tersedia di TikTok</p>
                  <a href={TIKTOK_URL} target="_blank" rel="noopener noreferrer" className="text-sm font-semibold text-white hover:text-white/80 transition-colors">
                    {TIKTOK_USERNAME}
                  </a>
                </div>
                <a href={TIKTOK_URL} target="_blank" rel="noopener noreferrer" className="flex-shrink-0 text-white/30 hover:text-white transition-colors">
                  <ExternalLink className="h-4 w-4" />
                </a>
              </div>
            </div>

            {/* Comments */}
            <div className="glass-panel rounded-2xl p-5 border border-white/8">
              <h3 className="text-base font-semibold text-white mb-4 flex items-center gap-2">
                <MessageCircle className="h-4 w-4 text-white/50" />
                Komentar {comments ? `(${comments.length})` : ""}
              </h3>
              {user && (
                <div className="flex gap-3 mb-5">
                  <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-xs text-white font-bold flex-shrink-0 overflow-hidden">
                    {(user as any).photoUrl
                      ? <img src={(user as any).photoUrl} alt={user.username} className="w-full h-full object-cover" />
                      : user.username.charAt(0).toUpperCase()
                    }
                  </div>
                  <div className="flex-1 space-y-2">
                    <Textarea
                      value={commentText}
                      onChange={(e) => setCommentText(e.target.value)}
                      placeholder="Tulis komentar..."
                      className="bg-white/5 border-white/10 text-white placeholder:text-white/25 resize-none text-sm"
                      rows={2}
                      onKeyDown={(e) => { if (e.key === "Enter" && e.ctrlKey) handleComment(); }}
                    />
                    <Button onClick={handleComment} size="sm" className="bg-white hover:bg-white/90 text-black font-medium" disabled={!commentText.trim() || createComment.isPending}>
                      {createComment.isPending ? "Mengirim..." : "Kirim"}
                    </Button>
                  </div>
                </div>
              )}
              {!user && (
                <div className="text-center py-3 mb-4">
                  <Link href="/login" className="text-sm text-white/40 hover:text-white transition-colors">
                    Login untuk berkomentar
                  </Link>
                </div>
              )}
              <div className="space-y-4">
                {comments?.map((comment) => (
                  <div key={comment.id} className="group flex gap-3">
                    <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-xs text-white font-bold flex-shrink-0">
                      {comment.username.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <Link href={`/users/${comment.userId}`} className="text-sm font-medium text-white/80 hover:text-white transition-colors">
                          {comment.username}
                        </Link>
                        <span className="text-xs text-white/25">{new Date(comment.createdAt).toLocaleDateString("id-ID")}</span>
                        {user && (user.id === comment.userId || user.role === "admin") && (
                          <button
                            onClick={() => { deleteComment.mutate({ id: comment.id }); invalidateComments(); }}
                            className="ml-auto opacity-0 group-hover:opacity-100 text-white/25 hover:text-red-400 transition-all"
                          >
                            <Trash2 className="h-3 w-3" />
                          </button>
                        )}
                      </div>
                      <p className="text-sm text-white/55 mt-0.5">{comment.text}</p>
                    </div>
                  </div>
                ))}
                {(!comments || comments.length === 0) && (
                  <p className="text-center text-sm text-white/20 py-4">Belum ada komentar</p>
                )}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-4">
            <div className="glass-panel rounded-2xl p-5 border border-white/8">
              <div className="flex flex-wrap gap-2 mb-3">
                <span className={`text-xs font-bold px-2 py-1 rounded text-black ${video.type === "slomo" ? "bg-white" : "bg-white/60"}`}>
                  {video.type === "slomo" ? "SLOMO" : "NORMAL"}
                </span>
              </div>
              <h1 className="text-xl font-bold text-white mb-3 leading-tight">{video.title}</h1>

              {video.drama && (
                <Link href={`/dramas/${video.drama.id}`} className="block text-sm text-white/70 hover:text-white mb-1 transition-colors">
                  {video.drama.name}
                </Link>
              )}
              {video.actor && (
                <Link href={`/actors/${video.actor.id}`} className="block text-xs text-white/40 hover:text-white/60 mb-3 transition-colors">
                  {video.actor.name}
                </Link>
              )}

              <div className="grid grid-cols-2 gap-3 text-xs">
                {video.episode && <div><span className="text-white/35">Episode</span><p className="text-white font-medium mt-0.5">{video.episode}</p></div>}
                {video.scene && <div><span className="text-white/35">Scene</span><p className="text-white font-medium mt-0.5">{video.scene}</p></div>}
                {video.resolution && <div><span className="text-white/35">Resolusi</span><p className="text-white font-medium mt-0.5">{video.resolution}</p></div>}
                {video.fps && <div><span className="text-white/35">FPS</span><p className="text-white font-medium mt-0.5">{video.fps}</p></div>}
                {video.format && <div><span className="text-white/35">Format</span><p className="text-white font-medium mt-0.5">{video.format}</p></div>}
                {video.fileSize && <div><span className="text-white/35">Ukuran</span><p className="text-white font-medium mt-0.5">{(video.fileSize / 1024 / 1024).toFixed(1)} MB</p></div>}
              </div>

              {video.tags && video.tags.length > 0 && (
                <div className="flex flex-wrap gap-1 mt-4">
                  {video.tags.map((tag, i) => (
                    <span key={i} className="text-[10px] px-2 py-0.5 rounded bg-white/8 text-white/40">#{tag}</span>
                  ))}
                </div>
              )}

              <div className="flex gap-4 mt-4 pt-4 border-t border-white/8 text-xs text-white/30">
                <span>{video.viewCount?.toLocaleString()} views</span>
                <span>{video.downloadCount?.toLocaleString()} downloads</span>
                <span>{video.favoriteCount?.toLocaleString()} likes</span>
              </div>
            </div>

            {video.relatedVideos && video.relatedVideos.length > 0 && (
              <div>
                <h3 className="text-sm font-medium text-white/60 mb-3">Clip Terkait</h3>
                <div className="grid grid-cols-2 gap-2">
                  {video.relatedVideos.slice(0, 4).map((v) => (
                    <VideoCard key={v.id} video={v} />
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Download Modal */}
      <Dialog open={showDownloadModal} onOpenChange={setShowDownloadModal}>
        <DialogContent className="glass-panel-strong border border-white/10 text-white max-w-sm">
          {downloadStep === "tiktok" ? (
            <>
              <DialogHeader>
                <DialogTitle className="text-white text-lg">Download Terkunci 🔒</DialogTitle>
              </DialogHeader>
              <div className="space-y-5 py-2">
                <p className="text-white/60 text-sm leading-relaxed">
                  Untuk download, kamu perlu kode akses. Kode tersedia di TikTok kami!
                </p>
                <a href={TIKTOK_URL} target="_blank" rel="noopener noreferrer"
                  className="block glass-panel rounded-xl p-4 border border-white/12 hover:border-white/25 transition-all group">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center flex-shrink-0">
                      <svg viewBox="0 0 24 24" className="h-6 w-6 fill-white" xmlns="http://www.w3.org/2000/svg">
                        <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1V9.01a6.33 6.33 0 00-.79-.05 6.34 6.34 0 00-6.34 6.34 6.34 6.34 0 006.34 6.34 6.34 6.34 0 006.33-6.34V8.69a8.18 8.18 0 004.78 1.52V6.76a4.85 4.85 0 01-1.01-.07z"/>
                      </svg>
                    </div>
                    <div>
                      <p className="text-sm text-white/50 mb-0.5">Follow & cari kode di</p>
                      <p className="font-bold text-white text-base group-hover:text-white/80 transition-colors">{TIKTOK_USERNAME}</p>
                    </div>
                    <ExternalLink className="h-4 w-4 text-white/30 ml-auto" />
                  </div>
                </a>
                <Button onClick={() => setDownloadStep("code")} className="w-full bg-white hover:bg-white/90 text-black font-semibold">
                  Sudah Follow? Masukkan Kode →
                </Button>
              </div>
            </>
          ) : (
            <>
              <DialogHeader>
                <DialogTitle className="text-white text-lg">Masukkan Kode Akses</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-2">
                <p className="text-white/50 text-sm">
                  Masukkan kode yang kamu dapat dari TikTok{" "}
                  <span className="text-white font-medium">{TIKTOK_USERNAME}</span>
                </p>
                <Input
                  value={codeInput}
                  onChange={(e) => setCodeInput(e.target.value.toUpperCase())}
                  placeholder="Contoh: TWIXTOR2024"
                  className="bg-white/5 border-white/12 text-white placeholder:text-white/25 text-center font-mono text-lg tracking-widest h-12"
                  onKeyDown={(e) => e.key === "Enter" && handleVerify()}
                />
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => setDownloadStep("tiktok")} className="flex-1 border-white/15 text-white/60 hover:text-white hover:bg-white/8">
                    ← Kembali
                  </Button>
                  <Button onClick={handleVerify} className="flex-1 bg-white hover:bg-white/90 text-black font-semibold" disabled={!codeInput.trim()}>
                    Verify & Download
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
