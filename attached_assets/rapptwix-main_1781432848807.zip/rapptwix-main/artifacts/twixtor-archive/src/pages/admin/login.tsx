import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Input } from "@/components/ui/input";
import { Shield, Lock } from "lucide-react";
import { Link, useLocation } from "wouter";
import EvilEye from "@/components/EvilEye";
import ElectricBorder from "@/components/ElectricBorder";

export default function AdminLogin() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const { login, user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (user?.role === "admin") setLocation("/admin");
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      await login({ username, password }, "/admin");
    } catch {
      setError("Username atau password salah");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col justify-center items-center p-5 relative overflow-hidden">
      {/* EvilEye background — red for admin */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div style={{ width: "min(90vw, 90vh)", height: "min(90vw, 90vh)", opacity: 0.18 }}>
          <EvilEye
            eyeColor="#ff4444"
            intensity={1.8}
            pupilSize={0.65}
            irisWidth={0.28}
            glowIntensity={0.5}
            scale={0.7}
            noiseScale={1.2}
            pupilFollow={0.6}
            flameSpeed={0.8}
            backgroundColor="#000000"
          />
        </div>
      </div>

      <Link href="/" className="absolute top-5 left-5 text-xs text-white/30 hover:text-white/60 transition-colors z-10">
        ← Kembali ke web
      </Link>

      <div className="relative z-10 w-full max-w-sm">
        <ElectricBorder color="#ff6060" speed={0.6} chaos={0.10} borderRadius={20}>
          <div className="glass-panel-strong rounded-2xl p-6 overflow-hidden relative">
            <div className="absolute top-0 left-8 right-8 h-[1px] bg-gradient-to-r from-transparent via-red-500/30 to-transparent" />

            <div className="text-center mb-7">
              <div className="w-14 h-14 rounded-2xl glass-panel border border-white/12 flex items-center justify-center mx-auto mb-4">
                <Shield className="h-7 w-7 text-white/70" />
              </div>
              <h1 className="text-xl font-bold text-white mb-1">Admin Panel</h1>
              <p className="text-white/35 text-[11px] tracking-widest uppercase">Twixtor Archive</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[11px] font-semibold text-white/40 uppercase tracking-widest">Username</label>
                <Input
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="bg-white/5 border-white/10 text-white h-12 rounded-xl focus:border-white/30 transition-colors text-base"
                  placeholder="owner"
                  required
                  autoComplete="username"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[11px] font-semibold text-white/40 uppercase tracking-widest">Password</label>
                <Input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="bg-white/5 border-white/10 text-white h-12 rounded-xl focus:border-white/30 transition-colors text-base"
                  placeholder="••••••••"
                  required
                  autoComplete="current-password"
                />
              </div>

              {error && (
                <div className="text-xs text-red-400 bg-red-400/10 border border-red-400/20 rounded-xl px-3 py-2.5">
                  {error}
                </div>
              )}

              <button
                type="submit"
                className="w-full h-12 mt-1 bg-white hover:bg-white/90 active:scale-95 text-black font-bold rounded-xl transition-all text-[15px] flex items-center justify-center gap-2"
                disabled={loading}
              >
                <Lock className="h-4 w-4" />
                {loading ? "Masuk..." : "Masuk sebagai Admin"}
              </button>
            </form>

            <div className="mt-4 bg-white/[0.04] rounded-xl px-4 py-3 border border-white/5">
              <p className="text-[11px] text-white/30 text-center">
                Default: <span className="text-white/50 font-mono">owner</span> / <span className="text-white/50 font-mono">twixtor2024</span>
              </p>
            </div>
          </div>
        </ElectricBorder>

        <p className="text-center text-[11px] text-white/20 mt-4">
          Bukan admin?{" "}
          <Link href="/login" className="text-white/40 hover:text-white/60 transition-colors">
            Login biasa
          </Link>
        </p>
      </div>
    </div>
  );
}
