import { setAuthTokenGetter } from "@workspace/api-client-react";

export function setupApi() {
  setAuthTokenGetter(() => {
    return localStorage.getItem("twixtor_token");
  });
}
